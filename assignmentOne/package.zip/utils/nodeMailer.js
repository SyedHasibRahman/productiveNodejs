

const nodeMailer = () => {
};

module.exports = nodeMailer;
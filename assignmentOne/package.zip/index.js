const express = require("express")
const dotenv = require("dotenv");
const cors = require("cors");
const connect = require("./utils/dbConnect");
const testRouter = require("./routes/v1/test.route.js")

const mongoose = require("mongoose");
const viewCount = require("./middleware/viewCount");
const { rateLimit } = require("express-rate-limit");
const port = process.env.PORT || 7000;
const app = express();
dotenv.config();

app.use(cors());
app.use(express.json());


// app.use(viewCount);
// mongoDB connecting using mongoose 
connect();

mongoose.connection.on("disconnected", () => {
    console.log("mongoDB disconnected!")
})
mongoose.connection.on("connected", () => {
    console.log("mongoDB connected!")
})



app.use("/api/v1/tests", testRouter)


app.all("*", (req, res) => {
    res.send("404 NO ROUTE FOUND!")
})
app.listen(port, () => {
    connect()
    console.log(`Connected to Backend on ${port}`)
})

module.exports.getTest = (req, res, next) => {
    res.send("TEST FOUND")
    // res.download(__dirname + "/test.controller.js");
    // console.log(req)
}
module.exports.getTestBYID = (req, res, next) => {
    console.log(req.params)
    res.send(`TEST FOUND ${req.params.id}`)
    // res.download(__dirname + "/test.controller.js");
    // console.log(req)
}

module.exports.saveTest = (req, res, next) => {
    res.send("TEST ADDED FOUND")
}

